//
//  newsCollectionCell.swift
//  vk
//
//  Created by user155176 on 28/08/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import UIKit

class NewsCollectionCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    var likeCount = 0
    var repostCount = 0;
    
    @IBOutlet weak var titleUi: UILabel!
    @IBOutlet weak var likesAmount: UILabel!
    @IBOutlet weak var dateUI: UILabel!
    @IBOutlet weak var avaUI: UIImageView!
    @IBOutlet weak var repostAmount: UILabel!
    
    
    
    @IBOutlet weak var likeLabel: UIButton!
    @IBOutlet weak var repostLabel: UIButton!
    
    
    @IBAction func likeButton(_ sender: Any) {
        likeCount += 1
       likesAmount.text = "\(likeCount)"
     
        UIView.animate(withDuration: 0.3, animations: {
            //self.likeLabel.frame.size.width += 2
           
            self.likesAmount.textColor = .red
            self.likeLabel.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
         
            
            
        }, completion: { (finished: Bool) in
           
            self.likeLabel.transform = CGAffineTransform(scaleX: 1, y: 1)
        })
        
    }
    
    
    @IBAction func repostButton(_ sender: Any) {
        repostCount += 1
        repostAmount.text = "\(repostCount)"
        
        UIView.animate(withDuration: 0.3, animations: {
            //self.likeLabel.frame.size.width += 2
            
          self.repostAmount.textColor = .purple
            self.repostLabel.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            
            
            
        }, completion: { (finished: Bool) in
            
            self.repostLabel.transform = CGAffineTransform(scaleX: 1, y: 1)
        })
        
        
    }
    
    
}

