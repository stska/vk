//
//  FriendsTableCellTableViewCell.swift
//  vk
//
//  Created by user155176 on 18/08/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import UIKit

class FriendsTableCell: UITableViewCell {
    @IBOutlet weak var uiLabelFriends: UILabel!
    @IBOutlet weak var uiImagaFriends: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        //uiImagaFriends.frame.size.width = 40
        //uiImagaFriends.frame.size.height = 40
        
        uiImagaFriends.addTapGestureRecognizer {
            print("Hiiiiiiiiiiiiii")
            UIView.animate(withDuration: 0.2,
                           delay: 0,
                           usingSpringWithDamping: 0.5,
                           initialSpringVelocity: 0,
                           options: [.autoreverse ],
                           animations: {
                            self.uiImagaFriends.frame.size.width -= 5
                            self.uiImagaFriends.frame.size.height -= 5
                            
                            
            },completion: {(finished: Bool) in
                self.uiImagaFriends.frame.size.width += 5
                self.uiImagaFriends.frame.size.height += 5
            })
            
            
            
            
        }
        // Configure the view for the selected state
    }
  
    
    
}
extension UIView {
    
    fileprivate struct AssociatedObjectKeys {
        static var tapGestureRecognizer = "MediaViewerAssociatedObjectKey_mediaViewer"
    }
    
    fileprivate typealias Action = (() -> Void)?
    
    
    fileprivate var tapGestureRecognizerAction: Action? {
        set {
            if let newValue = newValue {
                // Computed properties get stored as associated objects
                objc_setAssociatedObject(self, &AssociatedObjectKeys.tapGestureRecognizer, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN)
            }
        }
        get {
            let tapGestureRecognizerActionInstance = objc_getAssociatedObject(self, &AssociatedObjectKeys.tapGestureRecognizer) as? Action
            return tapGestureRecognizerActionInstance
        }
    }
    
    
    public func addTapGestureRecognizer(action: (() -> Void)?) {
        self.isUserInteractionEnabled = true
        self.tapGestureRecognizerAction = action
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTapGesture))
        self.addGestureRecognizer(tapGestureRecognizer)
    }
    
    
    @objc fileprivate func handleTapGesture(sender: UITapGestureRecognizer) {
        if let action = self.tapGestureRecognizerAction {
            action?()
        } else {
            print("no action")
        }
    }
    
}
