//
//  groupNameLabel.swift
//  vk
//
//  Created by user155176 on 15/08/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import UIKit

class groupNameLabel: UILabel {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
