//
//  Groups.swift
//  vk
//
//  Created by user155176 on 14/08/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import Foundation

class Groups{
    var groupName:String
    var groupsList:Array<String>
    
    init (groupName:String, groupsList:Array<String>){
        self.groupName = groupName
        self.groupsList = groupsList
    }
}
