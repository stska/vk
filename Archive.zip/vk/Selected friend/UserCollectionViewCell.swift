//
//  UserCollectionViewCell.swift
//  vk
//
//  Created by user155176 on 20/08/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import UIKit

class UserCollectionViewCell: UICollectionViewCell {
    
  //  @IBOutlet weak var userBigImage: UIImageView!
    //@IBOutlet weak var selectedUserName: UILabel!
    
    @IBOutlet weak var userAva: UIImageView!
    
    @IBOutlet weak var userGotName: UILabel!
    
    @IBOutlet weak var amountOfLikes: UILabel!
    
    @IBOutlet weak var likesButton: UIButton!
    var likes: Bool {
        get {
            return UserDefaults.standard.bool(forKey: "likes") ?? false
        }
        set {
            UserDefaults.standard.set(newValue, forKey: "likes")
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func toLike(_ sender: Any) {
        print("liked")
    }
      
    
    
}
