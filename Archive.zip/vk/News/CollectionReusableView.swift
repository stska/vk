//
//  CollectionReusableView.swift
//  vk
//
//  Created by user155176 on 28/08/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import UIKit

class CollectionReusableView: UICollectionReusableView {
        
}
