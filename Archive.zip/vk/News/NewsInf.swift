//
//  NewsInf.swift
//  vk
//
//  Created by user155176 on 29/08/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import Foundation
import UIKit

struct NewsInfo{
    let title:String
    let date:String
    let text:String
    let images:[UIImage]
}
